<footer class=" w-auto text-light" >
    <strong class="">Bitchest ©  2024</strong> 
</footer>