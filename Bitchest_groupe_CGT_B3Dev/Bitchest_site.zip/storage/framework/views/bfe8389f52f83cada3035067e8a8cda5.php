<?php $__env->startSection('bodycontent'); ?>
    <h2 class="text-light text-start mt-3 ms-3">Liste Des Clients</h2>
   <a href="<?php echo e(route('add.customer')); ?>" class="butt text-light "> <button type="submit" class="btn btn-secondary bg-gradient  w-25 mb-3">Add</button></a>
    <div class="container text-center">
        <div class="row">

            <div class="col-md-10 shadow p-3 mb-5 bg-body rounded ">
                <table class="table rounded ">
                    <thead>
                        <tr>
                            <th scope="col">id</th>
                            <th scope="col">Nom</th>
                            <th scope="col">Prenom</th>
                            <th scope="col">Age</th>
                            <th scope="col">Email</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                            $ide = 1;
                        ?>
                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <th scope="row"><?php echo e($ide); ?></th>
                                <td><?php echo e($items->firstname); ?></td>
                                <td><?php echo e($items->lastname); ?></td>
                                <td><?php echo e($items->age); ?></td>
                                <td><?php echo e($items->email); ?></td>
                                <td>

                                <a href="<?php echo e(route('modify.customer', ['id' => $items->id])); ?>" class="me-3"><button class="shadowe__btn">EDIT</button></a>
                               <button class="shadowd__btn me-3" onclick="return confirm('are you sure you want to delete this user?');"> <a href="<?php echo e(route('delete.customer', ['id' => $items->id])); ?>" >DELETE</a></button>
                                <a href="<?php echo e(route('view.customer', ['id' => $items->id])); ?>"  class="me-3"><button class="shadows__btn">SEE</button></a>
                                <a href="<?php echo e(route('deposit.customer', ['id' => $items->id])); ?>"><button class="shadowm__btn">DEPOSIT</button></a>
                                </td>

                            </tr>


                            <?php
                                $ide += 1;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\COULIBALY OUMOU\Documents\documents\3e-annee\Laravel\projet_bitchest\site\resources\views/pages/admin/customerAdmin.blade.php ENDPATH**/ ?>