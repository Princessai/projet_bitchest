<?php $__env->startSection('body'); ?>
    <div class="container text-center">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-8">
                <?php echo $__env->yieldContent('bodycontent'); ?>
            </div>
            <div class="col-md-12 col-md-12 col-lg-4 shadow-sm p-3 mb-5 rounded ">
                <?php echo $__env->yieldContent('sidecontent'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\COULIBALY OUMOU\Documents\documents\3e-annee\Laravel\projet_bitchest\site\resources\views/layouts/userDashboard.blade.php ENDPATH**/ ?>