<footer class=" w-auto text-light" >
    <strong class="">Bitchest ©  2024</strong> 
</footer><?php /**PATH C:\Users\COULIBALY OUMOU\Documents\documents\3e-annee\Laravel\projet_bitchest\site\resources\views/sections/footer.blade.php ENDPATH**/ ?>