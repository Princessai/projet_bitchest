<?php $__env->startSection('body'); ?>
    <div class="container text-center">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->yieldContent('bodycontent'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\COULIBALY OUMOU\Documents\documents\3e-annee\Laravel\projet_bitchest\site\resources\views/layouts/adminDashboard.blade.php ENDPATH**/ ?>