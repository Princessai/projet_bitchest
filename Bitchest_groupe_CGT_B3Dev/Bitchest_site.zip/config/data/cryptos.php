<?php

return [	
'Bitcoin'
,'Ethereum'
,'Ripple'
,'Bitcoin Cash'
,'Cardano'
,'Litecoin'
,'NEM'
,'Stellar'
,'IOTA'
,'Dash'
];