<?php $__env->startSection('profilebutton'); ?>
    <img src="<?php echo e(asset('assets/images/user.png')); ?>" alt="">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="container text-center">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">

                <div class="container text-start">
                    <div class="row">
                        <div class="col-lg-12 text-light mt-4">
                            <h3>Profile</h3>
                        </div>
                        <div class="col-lg-12 d-flex align-items-center mt-5">
                            <img src="<?php echo e(asset('assets/images/user2.png')); ?>" class="shadoww__btn" alt="">
                            <div>
                                <h3 class="ms-4 text-light"><?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->lastname); ?></h3>
                                <small class="ms-4 text-light opacity-75"><?php echo e(Auth::user()->email); ?></small>
                            </div>

                        </div>
                        <div class="col-lg-12 mt-5 shadow p-3 mb-5 bg-body rounded">
                            <h3><strong>Personal info</strong></h3>
                            <hr>
                            <div class="d-flex justify-content-between align-items-center">
                                <h5>Firstname</h5>
                                <h5 class="me-4"><?php echo e(Auth::user()->firstname); ?> </h5>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between align-items-center">
                                <h5>Lastname</h5>
                                <h5 class="me-4"><?php echo e(Auth::user()->lastname); ?></h5>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between align-items-center">
                                <h5>age</h5>
                                <h5 class="me-4"><?php echo e(Auth::user()->age); ?></h5>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between align-items-center">
                                <h5>Email</h5>
                                <h5 class="me-4"><?php echo e(Auth::user()->email); ?></h5>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between align-items-center">
                                <h5>Password</h5> <input type="password" disabled class="form-control w-50" name="password"
                                    value="<?php echo e(Auth::user()->password); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12 mb-5">
                        <div class="accordion accordion-flush " id="accordionFlushExample">
                            <div class="accordion-item ">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#flush-collapseOne" aria-expanded="false"
                                        aria-controls="flush-collapseOne">
                                        <strong> Edit your profile</strong>
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                    data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body">
                                        <form method="POST" action="<?php echo e(route('updateself')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="accordion-body">
                                                <input type="hidden" class="form-control" name="id"
                                                    value="<?php echo e(Auth::user()->id); ?>" id="exampleInputEmail1"
                                                    aria-describedby="emailHelp">
                                                <div class="mb-3">
                                                    <label for="exampleInputEmail1" class="form-label">Firstname</label>
                                                    <input type="text" class="form-control" name="firstname"
                                                        value="<?php echo e(Auth::user()->firstname); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleInputPassword1" class="form-label">Lastname</label>
                                                    <input type="text" class="form-control" name="lastname"
                                                        value="<?php echo e(Auth::user()->lastname); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleInputPassword1" class="form-label">Age</label>
                                                    <input type="number" class="form-control" name="age"
                                                        value="<?php echo e(Auth::user()->age); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleInputPassword1" class="form-label">Email</label>
                                                    <input type="email" class="form-control" name="email"
                                                        value="<?php echo e(Auth::user()->email); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleInputPassword1" class="form-label">Password</label>
                                                    <input type="password" class="form-control" name="password"
                                                        value="<?php echo e(Auth::user()->password); ?>">
                                                </div>

                                                <input type="submit" id="TextInput"
                                                    class="form-control shadoww__btn align-self-center" value="Edit">


                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\COULIBALY OUMOU\Documents\documents\3e-annee\Laravel\projet_bitchest\site\resources\views/pages/profile.blade.php ENDPATH**/ ?>