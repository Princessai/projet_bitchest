<?php $__env->startSection('walletbutton'); ?>
<a href="<?php echo e(route('list.customers')); ?>">
    <img src="<?php echo e(asset('assets/images/customer_icon.png')); ?>" alt="" class="butside"><br>
    <span class="text-light">Customers</span>
</a>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('profilebutton'); ?>
<a class="nav-link  align-self-center" href="<?php echo e(route('dashboard.admin')); ?>" >
<img src="<?php echo e(asset('assets/images/user.png')); ?>" alt="">
</a>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('body'); ?>
    <div class="container text-center">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12">
            <?php
include(base_path('documents/utils.php'))
    
?>
<div class="d-flex flex-column">
<h3 class=" mt-3 text-light text-start   ms-2  fw-semibold mb-4">List Crypto</h3>
<a href="<?php echo e(route('addcrypto')); ?>" class="align-self-start"><button class="shadoww__btn mb-5 ">Add Crypto</button></a>
</div>


    <div class="table-responsive rounded shadow p-3 mb-5 bg-body  rounded ">
        <table class="table text-nowrap   mb-5 mb-0 align-middle">
            <thead class="text-light fs-4">
                <tr>

                    <th class="border-bottom-0">
                        <h6 class="fw-semibold mb-0"></h6>
                    </th>
                    <th class="border-bottom-0">
                        <h6 class="fw-semibold mb-0">Name</h6>
                    </th>
                    <th class="border-bottom-0">
                        <h6 class="fw-semibold mb-0">current Course</h6>
                    </th>
                    <th class="border-bottom-0">
                        <h6 class="fw-semibold mb-0"></h6>
                    </th>
                    <th class="border-bottom-0">
                        <h6 class="fw-semibold mb-0"></h6>
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cryptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crypto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border-bottom-0">
                            <h6 class="fw-semibold mb-0"> <img src="<?php echo e(asset('assets/images/Bitcoin.png')); ?>" alt=""
                                    width="40%"></h6>
                        </td>
                        <td class="border-bottom-0">

                            <h6 class="fw-semibold mb-1"><?php echo e($crypto->label); ?></h6>
                        </td>
                        <td class="border-bottom-0">
                            <p class="mb-0 fw-normal"><?php echo e(getCoursActuel($crypto->id)); ?> €</p>
                        </td>
                        <td class="border-bottom-0">
                            <div class="d-flex align-items-center gap-2">
                                <a href="<?php echo e(route('cours.crypto', ['crypto_id'=>$crypto->id])); ?>"><button class="shadoww__btn">see more</button></a>
                               </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>
    </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\COULIBALY OUMOU\Documents\documents\3e-annee\Laravel\projet_bitchest\site\resources\views/pages/admin/AdminMarcheCrypto.blade.php ENDPATH**/ ?>