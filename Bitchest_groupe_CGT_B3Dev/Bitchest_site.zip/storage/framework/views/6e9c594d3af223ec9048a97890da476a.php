<?php $__env->startSection('bodycontent'); ?>

<div class="container mt-5 text-center">
        <div class="row">
            <div class="col-md-12 d-flex  align-items-center ">
                <img src="<?php echo e(asset('assets/images/bitcoin.png')); ?>" class="me-5" width="5%" alt="">
                <h1 class="text-light"><?php echo e($cryptoname); ?></h1>
            </div>
            <div class=" col-md-12 mt-5 mb-4  d-flex">
                <h3><button class="shadoww__btn">Overview</button></h3>
            </div>
            <div class="col-md-12 shadow-sm p-3 mb-5 bg-dark rounded">
                <div class="courbeCrypto">
                    <canvas id="myChart"></canvas>
                </div>

            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('do_transaction')): ?>
                <div class="col-md-12 text-light">
                    <h3>Transactions</h3>
                    <div>
                        <?php if($transactions->count() > 0): ?>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Crypto</th>
                                        <th>Purchased rate</th>
                                        <th>Type</th>
                                        <th>Date</th>
                                        <th>Quantity</th>
                                        <th>amount</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td> <?php echo e($cryptoname); ?> </td>
                                            <td> <?php echo e($transaction->cours_achat); ?> </td>
                                            <td> <?php echo e($transaction->type); ?> </td>
                                            <td> <?php echo e($transaction->date); ?> </td>
                                            <td> <?php echo e($transaction->quantite); ?> </td>
                                            <td> <?php echo e($transaction->montant); ?> </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>



                            </table>
                        <?php else: ?>
                            <p>
                                You don't have any transaction yet. Please add a new one to see it here!
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>


        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('do_transaction')): ?>
    <?php $__env->startSection('sidecontent'); ?>
        <div class="container text-center">
            <div class="row">
                <div class="col-md-12 mt-5">

                    <form action="<?php echo e(route('transaction', ['crypto_id' => $crypto_id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="">
                            <div>
                                <h5 class="text-light"> Votre solde: <?php echo e($solde); ?></h5>
                            </div>

                            <?php $__errorArgs = ['qte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="text" class="cleaninput mt-4" name="qte" value="<?php echo e(old('qte')); ?>">
                        </div>
                        <div class="mt-3">
                            <button type="submit" class="shadoww__btn" name="type" value="buy">Buy</button>
                            <button type="submit" class="shadoww__btn" name="type" value="sell">Sell</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php endif; ?>






<?php $__env->startPush('chart-scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        let cours = JSON.parse("<?php echo e($cours); ?>");
        let dates = JSON.parse('<?php echo $dates; ?>');
        console.log(cours);
        console.log(dates)

        const ctx = document.getElementById('myChart');


        const data = {
            labels: dates,
            datasets: [{
                    label: 'Dataset 1',
                    data: cours,
                    borderColor: "#01FF19",
                    backgroundColor: "#01FF19",
                },

            ]
        }

        const config = {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Cours actuel: <?php echo e($cryptoname); ?>'
                    }
                }
            },
        };

        new Chart(ctx, config)
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.userDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\COULIBALY OUMOU\Documents\documents\3e-annee\Laravel\projet_bitchest\site\resources\views/pages/courCrypto.blade.php ENDPATH**/ ?>