<?php $__env->startSection('bodycontent'); ?>
    <div class="container w-50
 mt-3 profile shadow p-3 mb-5 rounded rounded text-center">
        <div class="row">
            <div class="col-md-12 d-flex flex-column  mt-3  ">
                <h2 class="text-light">Add</h2>
                <form method="POST" action="<?php echo e(route('create.customer')); ?>">
                    <?php echo csrf_field(); ?>

                    <?php if(session()->has('success') && session()->get('success') == true): ?>
                        <div class="pop-up text-green border-radius-5 ">
                          <p>Customer added successfully !</p>
                          <p>Generated password : <?php echo e(session()->get('generatedPassword')); ?> !</p>
                        </div>
                    <?php endif; ?>
                    <h6 class="text-light">
                        Customer </h6>

                    <div class="mb-3">

                        <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input type="text" id="TextInput" name="firstname" class="form-control" placeholder="firstname"
                            value="<?php echo e(old('firstname')); ?>">
                    </div>
                    <div class="mb-3">
                        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input type="text" id="disabledTextInput" name="lastname" class="form-control"
                            placeholder="lastname" value="<?php echo e(old('lastname')); ?>">
                    </div>
                    <div class="mb-3">
                        <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input type="text" id="disabledTextInput" name="age" class="form-control" placeholder="age"
                            value="<?php echo e(old('age')); ?>">
                    </div>
                    <div class="mb-3">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <input type="text" id="disabledTextInput" name="email" class="form-control" placeholder="email"
                            value="<?php echo e(old('email')); ?>">
                    </div>
                    <input type="submit" id="TextInput" class="form-control align-self-center" value="create">
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php
   session()->forget(['success', 'generatedPassword']);
?>
<?php echo $__env->make('layouts.adminDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\COULIBALY OUMOU\Documents\documents\3e-annee\Laravel\projet_bitchest\site\resources\views/pages/admin/customerAdd.blade.php ENDPATH**/ ?>