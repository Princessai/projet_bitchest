<?php $__env->startSection('bodycontent'); ?>
    <?php
        use App\Models\Cotation;

    ?>

    <h5 class=" mt-3 text-info  ms-4  fw-semibold mb-4">BUY & SELL</h5>
    <div class="table-responsive rounded shadow p-3 mb-5 bg-body  rounded ">
        <table class="table text-nowrap   mb-5 mb-0 align-middle">
            <thead class="text-light fs-4">
                <tr>

                    <th class="border-bottom-0">
                        <h6 class="fw-semibold mb-0"></h6>
                    </th>
                    <th class="border-bottom-0">
                        <h6 class="fw-semibold mb-0">Name</h6>
                    </th>
                    <th class="border-bottom-0">
                        <h6 class="fw-semibold mb-0">current Course</h6>
                    </th>
                    <th class="border-bottom-0">
                        <h6 class="fw-semibold mb-0"></h6>
                    </th>
                    <th class="border-bottom-0">
                        <h6 class="fw-semibold mb-0"></h6>
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cryptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crypto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $isAdmin = Auth::user()->isAdmin();

                        $routeCourCrypto = route('cours.crypto.customer', ['crypto_id' => $crypto->id]);

                        if ($isAdmin) {
                            $routeCourCrypto = route('cours.crypto.admin', ['crypto_id' => $crypto->id]);
                        }
                    ?>

                    <tr>
                        <td class="border-bottom-0">
                            <h6 class="fw-semibold mb-0"> <img src="<?php echo e(asset('assets/images/Bitcoin.png')); ?>" alt=""
                                    width="40%"></h6>
                        </td>
                        <td class="border-bottom-0">

                            <h6 class="fw-semibold mb-1"><?php echo e($crypto->label); ?></h6>
                        </td>
                        <td class="border-bottom-0">
                            <p class="mb-0 fw-normal"><?php echo e(Cotation::getCoursActuel($crypto->id)); ?> €</p>
                        </td>
                        <td class="border-bottom-0">
                            <div class="d-flex align-items-center gap-2">
                                <a href="<?php echo e($routeCourCrypto); ?>"><button class="shadoww__btn">see more</button></a>
                            </div>
    </div>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </tbody>
    </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\COULIBALY OUMOU\Documents\documents\3e-annee\Laravel\projet_bitchest\site\resources\views/pages/marcheCrypto.blade.php ENDPATH**/ ?>